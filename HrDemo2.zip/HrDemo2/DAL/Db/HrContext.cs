﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Model;
using Microsoft.EntityFrameworkCore;

namespace DAL.Db
{
    public class HrContext : DbContext
    {
        public HrContext(DbContextOptions<HrContext> options) : base(options)
        {

        }
        public virtual DbSet<UserData> UserDatas { get; set; }
        public virtual DbSet<Grades> Grades { get; set; }
        public virtual DbSet<GradeHistory> GradeHistories { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserData>().HasKey(ud => ud.EmployeeId);
            modelBuilder.Entity<UserData>().Property(ud => ud.EmployeeId).UseIdentityColumn(100000, 1);
            modelBuilder.Entity<GradeHistory>().HasKey(gh => gh.Id);
            modelBuilder.Entity<Grades>().HasKey(g => g.ID);
            modelBuilder.Entity<UserData>().HasOne(ud => ud.Grade).WithMany(g => g.UserData).HasForeignKey(ud => ud.CurrentGradeId).OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<GradeHistory>().HasOne(ud => ud.User).WithMany(ud => ud.GradeHistories).HasForeignKey(gh => gh.EmployeeId).OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<GradeHistory>().HasOne(g => g.Grades).WithMany(g => g.GradeHistories).HasForeignKey(gh => gh.GradeID).OnDelete(DeleteBehavior.Restrict);

        }
    }
}

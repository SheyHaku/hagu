﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Model
{
    public class GradeHistory
     {
        [Required]
        public int Id { get; set; }
        public DateOnly AssignedOn { get; set; }
        [Required]
        public int EmployeeId { get; set; }
        [Required]
        public int GradeID { get; set; }
        public virtual UserData User {  get; set; } 
        public virtual Grades Grades { get; set; }  
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Model
{
    public class Grades
    {
        [Required]
        public int ID{get;set;}
        [Required]
        public string Name { get;set;}

        public virtual ICollection<UserData> UserData { get;set;}
        public virtual ICollection<GradeHistory> GradeHistories{ get;set;}

    }
}

﻿using DAL.Model;

using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;
 
namespace DAL.Repositary

{

    public interface IHR_REPO

    {

        public Task<bool> InsertEmployee(UserData employee);

        public Task<List<UserData>> GetAllEmployees();

        public Task DeleteEmployee(int employeeId);

        public Task<bool> UpdateEmployeeGrade(int employeeId, int CurrentGradeId);

        public Task<UserData?> GetEmployeeById(int employeeId);

        public Task<bool> UpdateEmployeeGrade(UserData employee);

    }

}

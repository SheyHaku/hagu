using BLL.Interface;
using DAL.Db;
using DAL.Repositary;
using BLL.service;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddDbContext<HrContext>(option =>
    option.UseSqlServer(builder.Configuration.GetConnectionString("dbcon"), db => db.MigrationsAssembly("DAL")));
builder.Services.AddScoped<IHR_REPO, HR_REPO>();
builder.Services.AddScoped<IHRTwo, HRTwo>();
builder.Services.AddScoped<IUserData, UserDataService>();
builder.Services.AddScoped<IGrades, GradeService>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: "CORS", builder =>
    {
        builder.AllowAnyOrigin()
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});


var app = builder.Build();

app.UseCors("CORS");
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
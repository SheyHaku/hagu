﻿using BLL.dto;
using BLL.Interface;
using DAL.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HrDemo2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserDataController : ControllerBase
    {
        private readonly IUserData _userService;

        public UserDataController(IUserData userService)
        {
            _userService = userService;
        }

        // GET: api/Users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserDTO>>> GetUsers()
        {
            return Ok(await _userService.GetEmployees());
        }

        // GET: api/Users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<UserData>> GetUser(int id)
        {
            var user = await _userService.GetEmployeeById(id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }

        // PUT: api/Users/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(int id, UserDTO user)
        {
            try
            {
                user.EmployeeId = id;
                await _userService.UpdateEmployee(user);

                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // POST: api/Users
        [HttpPost]
        public async Task<ActionResult> AddUser([FromBody] UserDTO user)
        {
            try
            {
                await _userService.AddEmployee(user);

                return CreatedAtAction("GetUser", new { id = user.EmployeeId }, user);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }


        }

        // DELETE: api/Users/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                await _userService.DeleteEmployee(id);


                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
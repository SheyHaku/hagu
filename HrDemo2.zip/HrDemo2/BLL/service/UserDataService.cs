﻿using BLL.dto;

using BLL.Interface;

using DAL.Model;

using DAL.Repositary;

using System;

using System.Collections.Generic;

using System.Data;

using System.Linq;

using System.Linq.Expressions;

using System.Net.Mail;

using System.Text;

using System.Threading.Tasks;

using static DAL.Model.UserData;
 
namespace BLL.service

{

    public class UserDataService : IUserData

    {

        private readonly IHR_REPO _employeeRepository;

        public UserDataService(IHR_REPO employeeRepository)

        {

            _employeeRepository = employeeRepository;

        }

        public async Task<List<UserDTO>> GetEmployees()

        {

            List<UserDTO> res = new List<UserDTO>();

            List<UserData> values = await _employeeRepository.GetAllEmployees();

            foreach (var user in values)

            {

                res.Add(new UserDTO

                {

                    EmployeeId = user.EmployeeId,

                    FirstName = user.FirstName,

                    LastName = user.LastName,

                    PhoneNumber = user.PhoneNumber,

                    EmailAddress = user.EmailAddress,

                    Role = user.Role,

                    CurrentGradeId = user.CurrentGradeId,

                });

            }

            return res;

        }

        public async Task<UserData> GetEmployeeById(int EmployeeId)

        {

            try

            {

                if (EmployeeId < 100000 || EmployeeId > 999999)

                {

                    throw new ArgumentException("Employee ID must be a valid 6 digit number.");

                }

                return await _employeeRepository.GetEmployeeById(EmployeeId);

            }

            catch

            {

                throw;

            }

        }

        public async Task<bool> AddEmployee(UserDTO employee)

        {

            // a. Validate employee ID

            /*if (employee.EmployeeId < 100000 || employee.EmployeeId > 999999)

            {

                throw new ArgumentException("Employee ID must be a valid 6 digit number.");

            }*/

            // b. Validate email address

            try

            {

                if (!employee.EmailAddress.EndsWith("@cognizant.com"))

                {

                    throw new ArgumentException("Email address must be in the format xxxx@cognizant.com");

                }


                UserData obj = new UserData

                {

                    EmployeeId = employee.EmployeeId,

                    FirstName = employee.FirstName,

                    LastName = employee.LastName,

                    EmailAddress = employee.EmailAddress,

                    PhoneNumber = employee.PhoneNumber,

                    Role = employee.Role,

                    CurrentGradeId = employee.CurrentGradeId

                };

                // e. Set default grade for TravelDeskExec

                if (employee.Role == UserRole.TravelDeskExe)

                {

                    if (obj.CurrentGradeId != 1)

                        throw new ArgumentException("TravelExec Id will always be 1");

                }

                bool insEmp = await _employeeRepository.InsertEmployee(obj);

                if (!insEmp)

                {

                    return false;

                }

                else

                {

                    return true;

                }

            }

            catch

            {

                throw;

            }

        }

        public async Task DeleteEmployee(int EmployeeId)

        {

            try

            {

                if (await GetEmployeeById(EmployeeId) != null)

                {

                    await _employeeRepository.DeleteEmployee(EmployeeId);

                }

                else

                {

                    throw new Exception("Invalid EmployeeId");

                }

            }

            catch

            {

                throw;

            }

        }

        public async Task<bool> UpdateEmployee(UserDTO employee)

        {

            try
            {

                var existingEmployee = await _employeeRepository.GetEmployeeById(employee.EmployeeId);



                if (existingEmployee == null) throw new ArgumentException("Employee Id doesn't exist");

                // c. Validate grade

                if (employee.CurrentGradeId < ((UserData)existingEmployee).CurrentGradeId)

                {

                    throw new ArgumentException("Grade of an employee should be allowed to go upwards not downwards.");

                }

                existingEmployee.FirstName = employee.FirstName;

                existingEmployee.LastName = employee.LastName;

                existingEmployee.EmailAddress = employee.EmailAddress;

                existingEmployee.PhoneNumber = employee.PhoneNumber;

                existingEmployee.Role = employee.Role;

                existingEmployee.CurrentGradeId = employee.CurrentGradeId;

                bool upEmp = await _employeeRepository.UpdateEmployeeGrade(existingEmployee);

                if (!upEmp)

                {

                    return false;

                }

                else

                {

                    return true;

                }

            }

            catch

            {

                throw;

            }

        }

    }

}
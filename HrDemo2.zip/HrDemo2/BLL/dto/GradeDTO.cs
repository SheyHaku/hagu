﻿using DAL.Model;
using DAL.Repositary;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.dto
{
    internal class GradeDto
    {
        public int ID { get; set; }
        public string Name { get; set; }


    }
}

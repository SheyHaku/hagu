import { Component } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
  //component decoratives which gives information about component to you angular app
})
export class UserComponent {//component class
//export means it is sends to the app.module so that it will call
}

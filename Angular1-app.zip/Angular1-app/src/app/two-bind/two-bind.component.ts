import { Component } from '@angular/core';

@Component({
  selector: 'app-two-bind',
  templateUrl: './two-bind.component.html',
  styleUrl: './two-bind.component.css'
})
export class TwoBindComponent {
  public displayName =' ';
    getMe(myfname:string , myLname:string)
 {
   this.displayName = myfname+ " " +myLname;
} 
//   getMe(value:string)
//  {
//    this.displayName = value;
// } 
//   getElement(value:string)
//  {
//    this.displayName = value;
// }
// getMe(value:string)
// {
//   console.log(value);
// } 
}

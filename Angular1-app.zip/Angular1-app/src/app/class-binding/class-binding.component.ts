import { Component } from '@angular/core';

@Component({
  selector: 'app-class-binding',
  templateUrl: './class-binding.component.html',
  styleUrl: './class-binding.component.css'
})
export class ClassBindingComponent {
public cssClass="myColor";
public condition =true;
mychoice()
{
  return "myColor";

}
}

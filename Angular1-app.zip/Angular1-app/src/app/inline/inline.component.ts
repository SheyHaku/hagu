import { Component } from '@angular/core';

@Component({
  selector: '.app-inline',
  //templateUrl: './inline.component.html',
  template:`<h2 class="title">DEBU DAS</h2>`,
  styles:[`
  .title{
    color:green;
    font-size:300%;
  }
  `]
 // styleUrl: './inline.component.css'
 /* styles:[`
  p{color:red;
  font-size:40px;}
  `]*/
})
export class InlineComponent {

}

import { Component } from '@angular/core';
//they are called as decoraters
@Component({ 
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
//component classs
export class AppComponent {
  //properties
  title = 'My heading';
  name='Tanmoy Das';
  //method
  helloMessage()
  {
    return "My Method is running under app component";
  }
}

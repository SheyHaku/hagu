import { Component } from '@angular/core';

@Component({
  selector: 'app-style-binding',
  templateUrl: './style-binding.component.html',
  styleUrl: './style-binding.component.css'
})
export class StyleBindingComponent {
myStyle={'color':'lightgreen',
'font-size':'60px',
'font-family':'cooper'};
}

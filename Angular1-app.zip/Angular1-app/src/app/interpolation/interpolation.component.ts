import { Component } from '@angular/core';

@Component({
  selector: 'app-interpolation',
  templateUrl: './interpolation.component.html',
  styleUrl: './interpolation.component.css'
})
export class InterpolationComponent { //Controller
//Model 
 public name="Tanmoy Das";
 public age= 24;
 MyMessage()
  {
    return "I love you";
  }
}

import { Component } from '@angular/core';
import { Console } from 'console';
import { CLIENT_RENEG_LIMIT } from 'tls';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrl: './event.component.css'
})
export class EventComponent {
//public name=" ";
  //OnCall(a:any)
  //{
    //alert("Love you y jaan!!");
    // console.log("You are good");
    // this.name = "Mantramurthy";
  //  alert(a);
  //}
  // OnCall(event:any)
  // {
  //   console.log(event);
  // }
  OnCall()
  {
    console.log("Hello");
  }
}
/*<button onclick="submit()">
function submit()
{alert("you are good");}*/
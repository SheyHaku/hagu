﻿using BLL.dto;
using DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Interface
{
    public interface IUserData
    {
        public Task<List<UserDTO>> GetEmployees();
        public Task<UserData> GetEmployeeById(int id);
        public Task<bool> AddEmployee(UserDTO employee);
         public Task DeleteEmployee(int id);
         public Task<bool> UpdateEmployee(UserDTO employee);
       
    }
}

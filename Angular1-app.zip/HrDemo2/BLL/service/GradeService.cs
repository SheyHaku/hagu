﻿using BLL.Interface;
using DAL.Db;
using DAL.Model;
using DAL.Repositary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.service
{
    public class GradeService:IGrades
    {
        private readonly IHRTwo _gradeRepository;

        public GradeService(IHRTwo gradeRepository)
        {
            _gradeRepository = gradeRepository;
        }
        public async Task<List<Grades>> GetGrade()
        {
            return await _gradeRepository.GetGrade();
        }
    }
}

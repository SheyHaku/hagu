﻿using DAL.Db;

using DAL.Model;

using Microsoft.EntityFrameworkCore;

using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;
 
 
namespace DAL.Repositary

{

    public class HR_REPO : IHR_REPO

    {

        private readonly HrContext _hrContext;

        public HR_REPO(HrContext dbContext)

        {

            _hrContext = dbContext;

        }

        public async Task DeleteEmployee(int employeeId)

        {

            var employee = await _hrContext.UserDatas.FindAsync(employeeId);

            if (employee != null)

            {

                _hrContext.UserDatas.Remove(employee);

                await _hrContext.SaveChangesAsync();

            }

        }

        public async Task<List<UserData>> GetAllEmployees()

        {

            return await _hrContext.UserDatas.ToListAsync();

        }

        public async Task<UserData?> GetEmployeeById(int employeeId)

        {

            var user = await _hrContext.UserDatas.FindAsync(employeeId);

            return user;

        }

        public async Task<bool> InsertEmployee(UserData employee)

        {

            try
            {

                await _hrContext.UserDatas.AddAsync(employee);

                await _hrContext.SaveChangesAsync();

                return true;

            }

            catch (ArgumentException ex)

            {

                throw;

            }


        }

        public async Task<bool> UpdateEmployeeGrade(int employeeId, int CurrentGradeId)

        {

            var employee = await _hrContext.UserDatas.FindAsync(employeeId);

            if (employee != null)

            {

                employee.CurrentGradeId = CurrentGradeId;

                await _hrContext.SaveChangesAsync();

                return true;

            }

            return false;

        }

        public async Task<bool> UpdateEmployeeGrade(UserData employee)

        {

            try

            {

                _hrContext.Update(employee);

                await _hrContext.SaveChangesAsync();

                return true;

            }

            catch

            {

                throw;

            }

        }

    }

}

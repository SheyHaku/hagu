﻿using DAL.Db;
using DAL.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repositary
{
    public class HRTwo:IHRTwo
    {
        private readonly HrContext _hrContext;
        public HRTwo(HrContext dbContext)
        {
            _hrContext = dbContext;
        }
        public async Task<List<Grades>> GetGrade()
        {
            return await _hrContext.Grades.ToListAsync();     
        }
    }
}

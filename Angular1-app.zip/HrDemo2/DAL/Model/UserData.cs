﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Model
{
    public class UserData
    {
        public enum UserRole
        {
            Employee,
            HR,
            TravelDeskExe
        }
        public int EmployeeId { get; set; }
        [Required]
        public string FirstName {  get; set; }
        [Required]
        public string LastName { get; set; }
        [Length(10,10,ErrorMessage ="Length Must be minimum 10 characters")]
        public string PhoneNumber { get; set; }
        [Required]
        public string EmailAddress { get; set; }
        [EnumDataType(typeof(UserRole), ErrorMessage = "Role must be Employee, HR, or TravelDeskExe")]
        public UserRole Role { get; set; }
        [Required]
        public int CurrentGradeId { get; set; }

        [DefaultValue(true)]
        public bool AccessGranted { get; set; }
        public virtual ICollection<GradeHistory> GradeHistories { get; set; }

        public virtual Grades Grade { get; set; }
    }
}

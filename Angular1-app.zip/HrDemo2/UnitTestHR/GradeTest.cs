﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BLL.Interface;
using BLL.service;
using BLL.dto;
using DAL.Model;
using DAL.Repositary;
using Moq;
 
 
namespace UnitTestHR
{
    [TestFixture]

    internal class gradeTest

    {

        private Mock<IHRTwo> _mockRepoTwo;

        private IGrades service;

        [SetUp]

        public void setUp()

        {

            _mockRepoTwo = new Mock<IHRTwo>();

            service = new GradeService(_mockRepoTwo.Object);

        }

        [Test]

        public async Task Test_CheckGradesCount_ReturnCount()

        {

            List<Grades> grade = new List<Grades>(){

            new Grades

            {

                ID = 1,

                Name = "Grade-1",

            },

            new Grades

            {

                ID = 2,

                Name = "Grade-2",

            }

        };

            _mockRepoTwo.Setup(m => m.GetGrade()).ReturnsAsync(grade);

            List<Grades> grades = await service.GetGrade();

            Assert.IsNotNull(grades);

            Assert.That(grades, Is.All.InstanceOf<Grades>());

            Assert.That(grades.Count, Is.GreaterThan(0));

        }

        [Test]

        public async Task Test_CheckGradesCount_EmptyCount()

        {

            List<Grades> empGrade = new List<Grades>();

            _mockRepoTwo.Setup(m => m.GetGrade()).ReturnsAsync(empGrade);

            Assert.IsNotNull(empGrade);

            Assert.That(empGrade, Is.Empty);

            Assert.That(empGrade.Count, Is.EqualTo(0));

        }

    }

}

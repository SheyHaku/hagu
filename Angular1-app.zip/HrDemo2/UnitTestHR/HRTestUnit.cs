
using Moq;

using BLL.service;

using BLL.Interface;

using BLL.dto;

using DAL.Repositary;

using DAL.Model;

using DAL.Db;

using Microsoft.EntityFrameworkCore.Infrastructure;

using Microsoft.EntityFrameworkCore;

using System.Data;

using System.Net.Mail;

using Microsoft.Identity.Client;

namespace UnitTestHR
{
    [TestFixture]

    public class HRTestUnit

    {

        private Mock<IHR_REPO> _mockRepo;

        private IUserData service;

        [SetUp]

        public void setUp()

        {

            _mockRepo = new Mock<IHR_REPO>();

            service = new UserDataService(_mockRepo.Object);

        }



        [Test]

        public async Task CanReturnAllEmployees()

        {

            List<UserData> employees = new List<UserData>()

            {

                new UserData{

                EmployeeId=100014,

                FirstName="water",

                LastName="bottle",

                PhoneNumber="9820220012",

                EmailAddress=" Manna@cognizant.com",

                Role=(UserData.UserRole)1,

                CurrentGradeId=2,

                AccessGranted=true,

                },

                new UserData{

                EmployeeId=1000789,

                FirstName="Soya",

                LastName="Sauce",

                PhoneNumber="6710910012",

                EmailAddress=" soya@cognizant.com",

                Role=(UserData.UserRole)2,

                CurrentGradeId=1,

                AccessGranted=true,

                }

            };

            _mockRepo.Setup(m => m.GetAllEmployees()).ReturnsAsync(employees);

            List<UserDTO> user = await service.GetEmployees();

            Assert.IsNotNull(user);

            Assert.That(user, Is.All.InstanceOf<UserDTO>());

            Assert.That(user.Count, Is.GreaterThan(0));

        }

        [Test]

        public async Task emptyList()

        {

            List<UserData> employees = new List<UserData>();

            _mockRepo.Setup(m => m.GetAllEmployees()).ReturnsAsync(employees);

            List<UserDTO> user = await service.GetEmployees();

            Assert.IsNotNull(user);

            Assert.That(user, Is.Empty);

            Assert.That(user.Count, Is.EqualTo(0));

        }

        [Test]

        public async Task GetEmployees_ThrowsException()

        {

            _mockRepo.Setup(m => m.GetAllEmployees()).ThrowsAsync(new Exception());

            Assert.ThrowsAsync<Exception>(async () =>

            {

                List<UserDTO> user = await service.GetEmployees();

            });

        }

        [Test]

        public async Task canReturnEmployeeById()

        {

            var employee = new UserData

            {

                EmployeeId = 100789,

                FirstName = "Soya",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@cognizant.com",

                Role = (UserData.UserRole)2,

                CurrentGradeId = 1,

                AccessGranted = true,

            };

            _mockRepo.Setup(m => m.GetEmployeeById(100789)).ReturnsAsync(employee);

            var employee1 = new UserDTO

            {

                EmployeeId = 100789,

                FirstName = "Soya",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@cognizant.com",

                Role = (UserData.UserRole)2,

                CurrentGradeId = 1,

            };

            var user = await service.GetEmployeeById(100789);

            Assert.IsNotNull(employee1);

            Assert.That(employee1, Is.InstanceOf<UserDTO>());

        }

        [Test]

        public async Task Null_employee_details()

        {

            _mockRepo.Setup(m => m.GetEmployeeById(100690)).ReturnsAsync((UserData?)null);

            var user = await service.GetEmployeeById(100690);

            Assert.That(user, Is.Null);

        }

        [Test]

        public async Task EmployeeId_notvalid()

        {

            Assert.ThrowsAsync<ArgumentException>(async () =>

            {

                var user = await service.GetEmployeeById(9999);

            }, "Employee ID must be a valid 6 digit number.");

        }

        [Test]

        public async Task AddEmployee_should_return_success()

        {

            var emp = new UserData

            {

                EmployeeId = 100789,

                FirstName = "Soya",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@cognizant.com",

                Role = (UserData.UserRole)2,

                CurrentGradeId = 1,

                AccessGranted = true,

            };

            _mockRepo.Setup(m => m.InsertEmployee(It.IsAny<UserData>())).ReturnsAsync(true);

            var emp2 = new UserDTO

            {

                EmployeeId = 100789,

                FirstName = "Soya",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@cognizant.com",

                Role = (UserData.UserRole)2,

                CurrentGradeId = 1,

            };

            var result = await service.AddEmployee(emp2);

            Assert.NotNull(result);

            Assert.That(result, Is.EqualTo(true));

        }

        [Test]

        public async Task AddEmployee_should_return_failed()

        {

            var addEmp = new UserDTO

            {

                EmployeeId = 100789,

                FirstName = "Soya",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@conizant.com",

                Role = (UserData.UserRole)2,

                CurrentGradeId = 2,

            };

            _mockRepo.Setup(m => m.InsertEmployee(It.IsAny<UserData>())).ReturnsAsync(false);

            Assert.ThrowsAsync<ArgumentException>(async () =>

            {

                var result = await service.AddEmployee(addEmp);

            }, "Email address must be in the format xxxx@cognizant.com");

        }

        [Test]

        public async Task update_CurrentGrade_success()

        {

            var UpEmp = new UserData

            {

                EmployeeId = 100789,

                FirstName = "Soya",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@conizant.com",

                Role = (UserData.UserRole)1,

                CurrentGradeId = 1,

            };

            _mockRepo.Setup(m => m.GetEmployeeById(UpEmp.EmployeeId)).ReturnsAsync(UpEmp);

            _mockRepo.Setup(m => m.UpdateEmployeeGrade(It.IsAny<UserData>())).ReturnsAsync(true);

            var UpEmp2 = new UserDTO

            {

                EmployeeId = 100789,

                FirstName = "chilli",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@conizant.com",

                Role = (UserData.UserRole)1,

                CurrentGradeId = 1,

            };

            var result = await service.UpdateEmployee(UpEmp2);

            Assert.NotNull(result);

            Assert.True(result);

        }

        [Test]

        public void UpdateEmployee_InvalidEmployeeId_ThrowsException()

        {

            // Arrange

            var invalidEmployeeId = 99999;

            var employeeDto = new UserDTO { EmployeeId = invalidEmployeeId };

            _mockRepo.Setup(repo => repo.GetEmployeeById(invalidEmployeeId)).ReturnsAsync((UserData?)null);

            // Act & Assert

            var ex = Assert.ThrowsAsync<ArgumentException>(async () => await service.UpdateEmployee(employeeDto));

            Assert.That(ex.Message, Is.EqualTo("Employee Id doesn't exist"));

        }

        [Test]

        public async Task DeleteEmployee_ValidEmployeeId_DeletesEmployee()

        {

            // Arrange

            var employeeId = 123456;

            var employee = new UserData { EmployeeId = employeeId };

            _mockRepo.Setup(repo => repo.GetEmployeeById(employeeId)).ReturnsAsync(employee);

            _mockRepo.Setup(repo => repo.DeleteEmployee(employeeId)).Returns(Task.CompletedTask);

            // Act

            await service.DeleteEmployee(employeeId);

            // Assert

            _mockRepo.Verify(repo => repo.DeleteEmployee(employeeId), Times.Once);

        }

        [Test]

        public void DeleteEmployee_InvalidEmployeeId_ThrowsException()

        {

            // Arrange

            var invalidEmployeeId = 999999;

            _mockRepo.Setup(repo => repo.GetEmployeeById(invalidEmployeeId)).ReturnsAsync((UserData)null);

            // Act & Assert

            var ex = Assert.ThrowsAsync<Exception>(() => service.DeleteEmployee(invalidEmployeeId));

            Assert.That(ex.Message, Is.EqualTo("Invalid EmployeeId"));

        }

        [Test]

        public async Task UpdateEmployee_InvalidCurrentGradeId()

        {

            var curEmp = new UserData

            {

                EmployeeId = 100789,

                FirstName = "Soya",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@conizant.com",

                Role = (UserData.UserRole)2,

                CurrentGradeId = 2,

            };

            _mockRepo.Setup(m => m.GetEmployeeById(curEmp.EmployeeId)).ReturnsAsync(curEmp);

            _mockRepo.Setup(m => m.UpdateEmployeeGrade(It.IsAny<UserData>())).ReturnsAsync(true);

            var CurEmp2 = new UserDTO

            {

                EmployeeId = 100789,

                FirstName = "chilli",

                LastName = "Sauce",

                PhoneNumber = "6710910012",

                EmailAddress = " soya@conizant.com",

                Role = (UserData.UserRole)2,

                CurrentGradeId = 2,

            };

            var result = await service.UpdateEmployee(CurEmp2);

            Assert.NotNull(result);

            Assert.True(result);

        }

    }

}
